from flask import Flask
from flask import render_template
from flask import Response
import cv2
import os


app = Flask(__name__)
cascPath=os.path.dirname(cv2.__file__)+"/data/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)
video_capture = cv2.VideoCapture(0)

def generate():
    while True:
    # Capture frame-by-frame
        ret, frames = video_capture.read()
        if ret:
            gray = cv2.cvtColor(frames, cv2.COLOR_BGR2GRAY)

            faces = faceCascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30),
                flags=cv2.CASCADE_SCALE_IMAGE
            )

            # Draw a rectangle around the faces
            for (x, y, w, h) in faces:
                cv2.rectangle(frames, (x, y), (x+w, y+h), (0, 255, 0), 2)

            font = cv2.FONT_HERSHEY_SIMPLEX
        
            # Use putText() method for
            # inserting text on video
            faces_str=str(len(faces))
            text=('Face Count: '+faces_str)
            cv2.putText(frames, 
                        text, 
                        (50, 50), 
                        font, 1, 
                        (0, 255, 255), 
                        2, 
                        cv2.LINE_4)
            (flag,encodedImage) = cv2.imencode(".jpg",frames) 

            if not flag:
                continue
            yield(b'--frame\r\n' b'Content-Type: image/gpeg\r\n\r\n' +
                bytearray(encodedImage) + b'\r\n')
        
@app.route("/")
def index():
    return render_template("public_html/index.html")

@app.route("/video_feed")
def video_feed():
    return Response(generate(),
        mimetype= "multipart/x-mixed-replace; boundary=frame")

if __name__ == "__main__":
    app.run(debug=True)

video_capture.release()